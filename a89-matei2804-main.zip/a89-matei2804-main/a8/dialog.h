<?xml version="1.0" encoding="UTF-8"?>
<ui version="4.0">
 <class>displayMovie</class>
 <widget class="QDialog" name="displayMovie">
  <property name="geometry">
   <rect>
    <x>0</x>
    <y>0</y>
    <width>320</width>
    <height>240</height>
   </rect>
  </property>
  <property name="windowTitle">
   <string>Dialog</string>
  </property>
  <layout class="QVBoxLayout" name="verticalLayout_2">
   <item>
    <layout class="QVBoxLayout" name="verticalLayout">
     <item>
      <widget class="QLabel" name="titleLabel">
       <property name="text">
        <string>Ttile</string>
       </property>
      </widget>
     </item>
     <item>
      <widget class="QLabel" name="genreLabel">
       <property name="text">
        <string>Genre</string>
       </property>
      </widget>
     </item>
     <item>
      <widget class="QLabel" name="yearLabel">
       <property name="text">
        <string>Year</string>
       </property>
      </widget>
     </item>
     <item>
      <widget class="QLabel" name="likesLabel">
       <property name="text">
        <string>Likes</string>
       </property>
      </widget>
     </item>
     <item>
      <widget class="QLabel" name="trailerLabel">
       <property name="text">
        <string>Trailer</string>
       </property>
      </widget>
     </item>
    </layout>
   </item>
   <item>
    <layout class="QHBoxLayout" name="horizontalLayout">
     <item>
      <widget class="QPushButton" name="addWatchListPushButton">
       <property name="text">
        <string>Add</string>
       </property>
      </widget>
     </item>
     <item>
      <widget class="QPushButton" name="nextPushButton">
       <property name="text">
        <string>Next</string>
       </property>
      </widget>
     </item>
     <item>
      <widget class="QPushButton" name="exitPushButton">
       <property name="text">
        <string>Exit</string>
       </property>
      </widget>
     </item>
    </layout>
   </item>
  </layout>
 </widget>
 <resources/>
 <connections/>
</ui>
